﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace estrutura_projeto
{
    public partial class frm_login : Form
    {
        public frm_login()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja mesmo sair?", "Estrutura Projeto", MessageBoxButtons.YesNo,MessageBoxIcon.Question) == DialogResult.Yes) 
{
                Application.Exit(); 
}
        }

        private void btn_entrar_Click(object sender, EventArgs e)
        {
            string user = "DS";
            string password = "123";

            if(txt_user.Text == user && txt_password.Text == password)
            {
                frm_main form = new frm_main();
                form.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Usuário e senha incorretos", "Estrutura Projeto");
            }
        }
    }
}

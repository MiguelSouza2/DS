﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using MySql.Data;
using System.Data;

namespace Animais_trabalho_CRUD
{
    class login : conexao
    {
        private string user;
        private string password;
        

        public void setUsuario_1(string user)
        {
            this.user = user;
        }
        public string getUsuario_l()
        {
            return this.user;
        }
        public void setSenha_1(string password)
        {
            this.password = password;
        }
        public string getSenha_l()
        {
            return this.password;
        }
        public int consultar_login()
        {
            this.abrirconexao();

            string mSQL = "SELECT COUNT(user) FROM login WHERE user='" + getUsuario_l() + "' AND password='" + getSenha_l() + "'";

            MySqlCommand cmd = new MySqlCommand(mSQL, conectar);
            MySqlDataAdapter da = new MySqlDataAdapter(cmd);
            Int32 result_query = Convert.ToInt32(cmd.ExecuteScalar());
            cmd.Dispose();

            int valor_login;
            valor_login = result_query;
            this.fecharconexao();
            return valor_login;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Animais_trabalho_CRUD
{
    public partial class frm_login : Form
    {
        public frm_login()
        {
            InitializeComponent();
        }

        

        private void btn_entrar_Click(object sender, EventArgs e)
        {
            login l = new login();
            l.setUsuario_1(txt_user.Text);
            l.setSenha_1(txt_password.Text);
            l.consultar_login();

            int value = l.consultar_login();

            if (value == 1)
            {
                frm_main form = new frm_main();
                form.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("Usuário e/ou senha inválidos!", "Acesso",
                MessageBoxButtons.OK,MessageBoxIcon.Exclamation);
            }

        }

        private void btn_sair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja mesmo sair?", "Estrutura Projeto", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}

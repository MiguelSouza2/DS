insert into login(user, password) values(
	'ds', 'ds'
)